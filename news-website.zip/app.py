
from flask import Flask, render_template
import requests

app = Flask(__name__)

@app.route('/')
def home():
    api_key = "YOUR_NEWS_API_KEY"  # Replace with your News API key
    url = f"https://newsapi.org/v2/top-headlines?country=us&pageSize=5&apiKey={api_key}"
    response = requests.get(url).json()
    articles = response.get('articles', [])
    return render_template('index.html', articles=articles)

if __name__ == '__main__':
    app.run(debug=True)
